#include "mainwindow.h"

#include <QApplication>
#include "widgetmanger.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    WidgetManger objWidgetMgr;
    objWidgetMgr.Run();

    return a.exec();
}
