#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow* MainWindow::m_pMainWindow = nullptr;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    m_pMainWindow = this;
}

MainWindow::~MainWindow()
{
    delete ui;
}

