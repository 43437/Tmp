#include "widgetmanger.h"
#include <QGridLayout>

WidgetManger::WidgetManger() : m_pMainWindow(nullptr)
                             , m_pPaintWidget(nullptr)
{
    Init();
}

void WidgetManger::Run()
{
    m_pMainWindow->show();
}

void WidgetManger::Init()
{
    m_pMainWindow = new MainWindow();
    QWidget* pContainer = new QWidget(m_pMainWindow);
    QGridLayout* layout = new QGridLayout(pContainer);
    pContainer->setLayout(layout);

    m_pPaintWidget = new PaintWidget(m_pMainWindow);
    layout->addWidget(m_pPaintWidget);

    m_pMainWindow->setCentralWidget(pContainer);

    m_pPaintWidget->setStyleSheet("PaintWidget {color: #00ff5a; background-color: #ff0000}");
}
