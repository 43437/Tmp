#ifndef WIDGETMANGER_H
#define WIDGETMANGER_H

#include "mainwindow.h"
#include "paintwidget.h"

class WidgetManger
{
public:
    WidgetManger();
    void Run();

private:
    void Init();

private:
    MainWindow              *m_pMainWindow;
    PaintWidget             *m_pPaintWidget;
};

#endif // WIDGETMANGER_H
