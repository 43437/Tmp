#include "paintwidget.h"
#include <QPaintEvent>
#include <QDebug>
#include <QApplication>
#include "mainwindow.h"
#include <QStyleOption>
#include <QPainter>
#include <QPalette>

PaintWidget::PaintWidget(QWidget *parent)
    : QWidget{parent}
    , m_pLabel(nullptr)
{
    Init();
}

void PaintWidget::Init()
{
    m_pLabel = new QLabel();
    m_pLabel->setText("hell world");
    m_pLabel->setStyleSheet("border: 2px solid #ff0000");
    m_pLabel->installEventFilter(new LabelMove(this));

    qDebug() << "label: " << m_pLabel;
}

bool PaintWidget::event(QEvent *event)
{
    qDebug() << "event: " << event->type();

    if (QEvent::ContextMenu == event->type())
    {
        update();
    }

    return QWidget::event(event);
}

void PaintWidget::paintEvent(QPaintEvent *event)
{
    QRect rect = event->rect();
    qDebug() << "paintEvent" << rect << " " << event->type();

    qDebug() << "mainwindow: " << MainWindow::m_pMainWindow->rect();

    QPainter p( this );
    qDebug() << "brush: " << palette().brush(QPalette::Current, QPalette::Window);
    qDebug() << "color: " << palette().color(QPalette::Current, QPalette::Text);

    QStyleOption opt;
    opt.initFrom(this);
    style()->drawPrimitive(QStyle::PE_Widget, &opt, &p, this);

    p.drawText(QPoint(150, 150), "hello widget");
    p.drawRect(QRect(150, 150, 50, 20));
    p.drawEllipse(this->rect());

    QWidget::paintEvent(event);
}
