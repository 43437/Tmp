#ifndef PAINTWIDGET_H
#define PAINTWIDGET_H

#include <QWidget>
#include <QLabel>
#include <QObject>
#include <QEvent>
#include <QMouseEvent>

class LabelMove : public QObject
{
    Q_OBJECT
public:
    explicit LabelMove(QObject* parent) : QObject(parent)
    {
    };

    virtual bool eventFilter(QObject *watched, QEvent *event)
    {
        qDebug() << "obj: " << watched << " event: " << event->type();
        if (event->type() == QEvent::MouseMove)
        {
            QMouseEvent* me = static_cast<QMouseEvent*>(event);
            QLabel* lb = static_cast<QLabel*>(watched);
            lb->move(me->pos().x(), me->pos().y());        }
    };
};

class PaintWidget : public QWidget
{
    Q_OBJECT
public:
    explicit PaintWidget(QWidget *parent = nullptr);

protected:
    virtual void paintEvent(QPaintEvent *event);
    bool event(QEvent *event) override;

private:
    void Init();

signals:

private:
    QLabel*         m_pLabel;

};

#endif // PAINTWIDGET_H
