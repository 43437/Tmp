#ifndef PAINTWIDGET_H
#define PAINTWIDGET_H

#include <QWidget>

class PaintWidget : public QWidget
{
    Q_OBJECT

public:
    explicit PaintWidget(QWidget *parent = nullptr);
    ~PaintWidget();

protected:
    virtual void paintEvent(QPaintEvent *event);

private:
    void DrawMachine();
    void DrawTrack();
    void DrawMovement();
    int GetInterSpace();
    int GetHBorderSpace();
    int GetVBorderSpace();
    int GetMachineWidth();
    int GetMachineHeight();
    QPoint GetMachineStart();
    QPoint GetMachineNextPos(const QPoint& point);
    QList<QLine> GetTracks();
    void DrawArrow(const QPoint& p);
    int GetArrowWidth();
    int GetArrowHeight();
};

#endif // PAINTWIDGET_H
