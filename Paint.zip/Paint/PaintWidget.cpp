#include "PaintWidget.h"
#include <QPainterPath>
#include <QPainter>

PaintWidget::PaintWidget(QWidget *parent) :
    QWidget(parent)
{

}

PaintWidget::~PaintWidget()
{

}

void PaintWidget::paintEvent(QPaintEvent *event)
{
//    QPainterPath path;
////    path.setFillRule(Qt::WindingFill);
//    path.addRect(10, 10, this->width()-20, this->height()-20);

//    QPainter painter(this);
////    painter.setRenderHint(QPainter::Antialiasing, true);
////    painter.fillPath(path, QBrush(Qt::white));

//    QColor color(0, 0, 0, 50);
//    for(int i=0; i<10; i++)
//    {
//        QPainterPath path;
////        path.setFillRule(Qt::WindingFill);
//        path.addRect(10-i, 10-i, this->width()-(10-i)*2, this->height()-(10-i)*2);
//        color.setAlpha(150 - qSqrt(i)*50);
//        painter.setPen(color);
//        painter.drawPath(path);
//    }
    DrawMachine();
    DrawTrack();
    DrawMovement();
}

int PaintWidget::GetInterSpace()
{
    return 50;
}

int PaintWidget::GetMachineWidth()
{
    return (this->width() - GetHBorderSpace() * 2 - GetInterSpace() * 3) / 4;
}

QPoint PaintWidget::GetMachineStart()
{
    return QPoint(GetHBorderSpace(), GetVBorderSpace());
}

QPoint PaintWidget::GetMachineNextPos(const QPoint& point)
{
    return QPoint(point.x() + GetMachineWidth() + GetInterSpace(), point.y());
}

int PaintWidget::GetMachineHeight()
{
    return this->height() - GetVBorderSpace() * 2;
}

int PaintWidget::GetHBorderSpace()
{
    return 100;
}

int PaintWidget::GetVBorderSpace()
{
    return 20;
}

void PaintWidget::DrawMachine()
{
    QPoint Pos = GetMachineStart();
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing, true);
    int mwidth = GetMachineWidth();
    int mheight = GetMachineHeight();

    for (int i = 0; i < 4; ++i)
    {
        QRect rect(Pos.x(), Pos.y(), mwidth, mheight);
        QPainterPath path;
        path.addRect(rect);

        path.moveTo(rect.topLeft());
        path.lineTo(rect.bottomRight());
        path.moveTo(rect.topRight());
        path.lineTo(rect.bottomLeft());

        painter.drawPath(path);
        Pos = GetMachineNextPos(Pos);
    }
}

QList<QLine> PaintWidget::GetTracks()
{
    QList<QLine> lstTrack;

    QLine ln;
    QPoint pos = GetMachineStart();
    int height = GetMachineHeight();
    int width = GetMachineWidth();
    int y = pos.y() + height / 2;

    for (int i = 0; i < 3; ++i)
    {
        int x = pos.x() + width;
        ln.setP1(QPoint(x, y));
        pos = GetMachineNextPos(pos);
        x = pos.x();
        ln.setP2(QPoint(x, y));
        lstTrack << ln;
    }

    return lstTrack;
}

void PaintWidget::DrawTrack()
{
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing, true);
    QList<QLine> lstTracks = GetTracks();
    painter.drawLines(lstTracks);
}

void PaintWidget::DrawMovement()
{
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing, true);
    QList<QLine> lstTracks = GetTracks();
    DrawArrow(lstTracks[0].p2());
}

int PaintWidget::GetArrowWidth()
{
    return 40;
}

int PaintWidget::GetArrowHeight()
{
    return 10;
}

void PaintWidget::DrawArrow(const QPoint& p)
{
    int w = GetArrowWidth();
    int h = GetArrowHeight();

    QPainterPath path;
    path.moveTo(QPoint(p.x(), p.y() + h));
    path.lineTo(QPoint(p.x() + w, p.y()));
    path.lineTo(QPoint(p.x(), p.y() - h));
    path.lineTo(QPoint(p.x(), p.y() + h));

    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing, true);
    painter.fillPath(path, QBrush(Qt::black));
    painter.drawPath(path);
}
