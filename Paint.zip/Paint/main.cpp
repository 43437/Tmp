#include "mainwindow.h"

#include <QApplication>
#include "CenterWidget.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;

    CenterWidget* widget = new CenterWidget(&w);
    w.setCentralWidget(widget);

    w.show();
    return a.exec();
}
