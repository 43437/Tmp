#ifndef CENTERWIDGET_H
#define CENTERWIDGET_H

#include <QWidget>
#include <QTableView>
#include <QList>
#include "buttonwidget.h"

namespace Ui {
class CenterWidget;
}

struct ModelData
{
    QString m_strName;
    int     m_iAge;
    int     m_Gender;
};

class CustumModel: public QAbstractListModel
{
public:
    CustumModel(QObject *parent = nullptr);

    virtual int rowCount(const QModelIndex &parent = QModelIndex()) const;
    virtual int columnCount(const QModelIndex &parent = QModelIndex()) const;
    virtual QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const;

private:
    void Init();

private:
    QList<ModelData>            m_lstModelData;
};

class CenterWidget : public QWidget
{
    Q_OBJECT

public:
    explicit CenterWidget(QWidget *parent = nullptr);
    ~CenterWidget();

private:
    void Init();

private:
    Ui::CenterWidget            *ui;
    QTableView*                 m_pTableView;
    CustumModel*                m_pModel;
    ButtonWidget*               m_pButtonWidget;
};

#endif // CENTERWIDGET_H
