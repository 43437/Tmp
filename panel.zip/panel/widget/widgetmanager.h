#ifndef WIDGETMANAGER_H
#define WIDGETMANAGER_H

#include <QObject>
#include <QMutex>
#include "mainwindow.h"
#include "centerwidget.h"

class WidgetManager : public QObject
{
    Q_OBJECT
public:
    static WidgetManager* GetInstance();
public:
    explicit WidgetManager(QObject *parent = nullptr);
    void Run();

signals:

private:
    void Init();

private:
    static QMutex               m_mutex;
    static WidgetManager*       m_pInstance;
    MainWindow*                 m_pMainWind;
    CenterWidget*               m_pCenterWidget;
};

#endif // WIDGETMANAGER_H
