#ifndef BUTTONWIDGET_H
#define BUTTONWIDGET_H

#include <QWidget>
#include <QTableWidget>
#include "common/stylesheetmanager.h"

class ButtonWidget : public QWidget
{
    Q_OBJECT
public:
    explicit ButtonWidget(QWidget *parent = nullptr);

signals:

private:
    void Init();

private:
    QTableWidget            *m_pTableWidget;
};

#endif // BUTTONWIDGET_H
