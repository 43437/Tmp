#include "centerwidget.h"
#include "ui_centerwidget.h"

CustumModel::CustumModel(QObject *parent) : QAbstractListModel(parent)
{
    Init();
}

void CustumModel::Init()
{
    for (int i = 0; i < 4; ++i)
    {
        ModelData data;
        data.m_strName = QString("name %1").arg(i);
        data.m_iAge = i;
        data.m_Gender = i % 2;
        m_lstModelData << data;
    }
}

int CustumModel::rowCount(const QModelIndex &parent /*= QModelIndex()*/) const
{
    return m_lstModelData.size();
}

int CustumModel::columnCount(const QModelIndex &parent /*= QModelIndex()*/) const
{
    return 3;
}

QVariant CustumModel::data(const QModelIndex &index, int role /*= Qt::DisplayRole*/) const
{
    int row = index.row();
    int col = index.column();

    switch (role)
    {
    case Qt::DisplayRole:
    {
        const ModelData& data = m_lstModelData[row];
        switch (col)
        {
        case 0:
            return data.m_strName;
            break;
        case 1:
            return data.m_iAge;
            break;
        case 2:
            return data.m_Gender;
            break;
        default:
            return QVariant();
            break;
        }
        break;
    }
    default:
        break;
    }

    return QVariant();
}

CenterWidget::CenterWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CenterWidget),
    m_pTableView(nullptr),
    m_pButtonWidget(nullptr)
{
    ui->setupUi(this);
    Init();
}

CenterWidget::~CenterWidget()
{
    delete ui;
}

void CenterWidget::Init()
{
    {
        m_pTableView = new QTableView(this);
        m_pModel = new CustumModel();
        m_pTableView->setModel(m_pModel);
        m_pTableView->setGeometry(20, 300, 350, 280);
        m_pTableView->setColumnWidth(0, 200);
        m_pTableView->setColumnWidth(1, 100);
        m_pTableView->setColumnWidth(2, 100);
    }
    {
        m_pButtonWidget = new ButtonWidget(this);

        ButtonWidget* pButtonWidget = new ButtonWidget(this);
        ui->tabWidget->addTab(m_pButtonWidget, "All");
        ui->tabWidget->addTab(pButtonWidget, "section");
    }
}
