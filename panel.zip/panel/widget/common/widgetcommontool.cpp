#include "widgetcommontool.h"
#include <QFile>

QString WidgetCommonTool::m_ResourceDir(":/resource/");

WidgetCommonTool::WidgetCommonTool()
{

}

QString WidgetCommonTool::LoadStyleSheet(const QString& fileName)
{
    QString strFile = QString("%1%2").arg(m_ResourceDir).arg(fileName);
    QFile file(strFile);
    QString styleSheet("");
    if (file.open(QFile::ReadOnly))
    {
        styleSheet = file.readAll();
    }

    return styleSheet;
}
