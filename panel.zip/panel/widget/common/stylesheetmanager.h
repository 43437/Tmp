#ifndef StyleSheetManager_H
#define StyleSheetManager_H

#include <QString>
#include <QList>
#include <QWidget>

class StyleSheetManager
{
public:
    explicit StyleSheetManager();
    StyleSheetManager& Load(const QString& styleSheet);
    StyleSheetManager& Target(QWidget* widget);
    StyleSheetManager& Reset();
    StyleSheetManager& Apply();

private:
    QList<QString>              m_lstLayout;
    QWidget*                    m_pWidget;
    QString                     m_strStyleSheet;
};

#endif // StyleSheetManager_H
