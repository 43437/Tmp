#include "stylesheetmanager.h""
#include "common/widgetcommontool.h"

StyleSheetManager::StyleSheetManager() : m_pWidget(nullptr)
{
}

StyleSheetManager& StyleSheetManager::Load(const QString& styleSheet)
{
    m_strStyleSheet += WidgetCommonTool::LoadStyleSheet(styleSheet);
    return *this;
}

StyleSheetManager& StyleSheetManager::Reset()
{
    m_strStyleSheet.clear();
    return *this;
}

StyleSheetManager& StyleSheetManager::Apply()
{
    if (nullptr != m_pWidget)
    {
        m_pWidget->setStyleSheet(m_strStyleSheet);
    }
    return *this;
}

StyleSheetManager& StyleSheetManager::Target(QWidget* widget)
{
    m_pWidget = widget;
}
