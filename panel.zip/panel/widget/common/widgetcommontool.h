#ifndef WIDGETCOMMONTOOL_H
#define WIDGETCOMMONTOOL_H

#include <QString>

class WidgetCommonTool
{
public:
    static QString LoadStyleSheet(const QString& fileName);

private:
    WidgetCommonTool();

public:
    static QString                  m_ResourceDir;
};

#endif // WIDGETCOMMONTOOL_H
