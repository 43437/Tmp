#include "widgetmanager.h"

QMutex WidgetManager::m_mutex;
WidgetManager* WidgetManager::m_pInstance = nullptr;

WidgetManager* WidgetManager::GetInstance()
{
    if (nullptr == m_pInstance)
    {
        m_mutex.lock();
        if (nullptr == m_pInstance)
        {
            m_pInstance = new WidgetManager();
        }
        m_mutex.unlock();
    }
    return m_pInstance;
}

WidgetManager::WidgetManager(QObject *parent) : QObject(parent)
                                              , m_pMainWind(nullptr)
                                              , m_pCenterWidget(nullptr)
{
    Init();
}

void WidgetManager::Init()
{
    m_pMainWind = new MainWindow();
    m_pCenterWidget = new CenterWidget(m_pMainWind);
}

void WidgetManager::Run()
{
    m_pMainWind->show();
}
