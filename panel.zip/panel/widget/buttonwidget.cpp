#include "buttonwidget.h"
#include <QPushButton>
#include <QGridLayout>
#include <QHeaderView>
#include "common/widgetcommontool.h"
#include "common/stylesheetmanager.h"
#include <QItemDelegate>


ButtonWidget::ButtonWidget(QWidget *parent) : QWidget(parent)
{
    Init();
}

void ButtonWidget::Init()
{
    m_pTableWidget = new QTableWidget(this);
    m_pTableWidget->setRowCount(20 / 4);
    m_pTableWidget->setColumnCount(4);

    QGridLayout* pGridLayout = new QGridLayout();
    this->setLayout(pGridLayout);
    pGridLayout->addWidget(m_pTableWidget);
    for (int i = 0; i < 18; ++i)
    {
        int row = i / 4;
        int col = i % 4;
        m_pTableWidget->setCellWidget(row, col, new QPushButton(this));
        qobject_cast<QPushButton*>( m_pTableWidget->cellWidget(row, col))->setCheckable(true);
    }
    m_pTableWidget->horizontalHeader()->hide();
    m_pTableWidget->verticalHeader()->hide();
    m_pTableWidget->setShowGrid(false);

    StyleSheetManager().Load("tablebutton.css")
                        .Target(this)
                        .Apply();
}
